# CLDR Common Data

This zipfile contains [CLDR](http://cldr.unicode.org) Common Data.

## LICENSE

See [LICENSE.txt](./LICENSE.txt)

>Copyright © 2019-2022 Unicode, Inc. All rights reserved.
>Distributed under the Terms of Use in https://www.unicode.org/copyright.html